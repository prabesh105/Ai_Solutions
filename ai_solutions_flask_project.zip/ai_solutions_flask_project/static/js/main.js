const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

// Mobile navigation
const menuButton = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');
if (menuButton && navLinks) {
  menuButton.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    menuButton.setAttribute('aria-expanded', navLinks.classList.contains('active') ? 'true' : 'false');
  });
}

// Admin sidebar
const sidebarToggle = document.querySelector('.sidebar-toggle');
const adminSidebar = document.querySelector('.admin-sidebar');
if (sidebarToggle && adminSidebar) sidebarToggle.addEventListener('click', () => adminSidebar.classList.toggle('open'));

// Auto-hide flash messages
for (const alertBox of document.querySelectorAll('.alert')) {
  setTimeout(() => {
    alertBox.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
    alertBox.style.opacity = '0';
    alertBox.style.transform = 'translateY(-8px)';
    setTimeout(() => alertBox.remove(), 450);
  }, 5500);
}

// Confirm delete actions
for (const form of document.querySelectorAll('form[data-confirm]')) {
  form.addEventListener('submit', (event) => {
    const message = form.getAttribute('data-confirm') || 'Are you sure?';
    if (!window.confirm(message)) event.preventDefault();
  });
}

// Reveal animation
const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && revealItems.length) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach((item) => {
    item.style.opacity = '0';
    item.style.transform = 'translateY(18px)';
    item.style.transition = 'opacity .6s ease, transform .6s ease';
    observer.observe(item);
  });
}

// Animated counters
for (const counter of document.querySelectorAll('[data-count]')) {
  const target = Number(counter.dataset.count || 0);
  let current = 0;
  const step = Math.max(1, Math.ceil(target / 55));
  const timer = setInterval(() => {
    current += step;
    if (current >= target) { current = target; clearInterval(timer); }
    counter.textContent = current;
  }, 22);
}

// Testimonial carousel: shows 3 on desktop, loops continuously
const slider = document.querySelector('[data-slider="testimonials"]');
if (slider) {
  const track = slider.querySelector('.testimonial-track');
  const cards = Array.from(slider.querySelectorAll('.testimonial-card'));
  const nextBtn = slider.querySelector('.next');
  const prevBtn = slider.querySelector('.prev');
  let index = 0;
  const gap = 20;
  function visibleCount() { return window.innerWidth <= 760 ? 1 : (window.innerWidth <= 1050 ? 2 : 3); }
  function updateSlider() {
    if (!track || !cards.length) return;
    const cardWidth = cards[0].getBoundingClientRect().width + gap;
    track.style.transform = `translateX(-${index * cardWidth}px)`;
  }
  function moveNext() { const maxIndex = Math.max(cards.length - visibleCount(), 0); index = index >= maxIndex ? 0 : index + 1; updateSlider(); }
  function movePrev() { const maxIndex = Math.max(cards.length - visibleCount(), 0); index = index <= 0 ? maxIndex : index - 1; updateSlider(); }
  nextBtn?.addEventListener('click', moveNext);
  prevBtn?.addEventListener('click', movePrev);
  window.addEventListener('resize', updateSlider);
  updateSlider();
  if (cards.length > visibleCount()) setInterval(moveNext, 3600);
}

// Gallery modal / lightbox
const galleryModal = document.querySelector('.gallery-modal');
if (galleryModal) {
  const modalImage = galleryModal.querySelector('.gallery-modal-image');
  const modalTitle = galleryModal.querySelector('h3');
  const modalDescription = galleryModal.querySelector('p');
  const closeButton = galleryModal.querySelector('.gallery-close');
  document.querySelectorAll('.gallery-card').forEach((card) => {
    card.addEventListener('click', () => {
      modalTitle.textContent = card.dataset.galleryTitle || 'Gallery Image';
      modalDescription.textContent = card.dataset.galleryDescription || '';
      const image = card.dataset.galleryImage || '';
      modalImage.className = 'gallery-modal-image';
      modalImage.style.backgroundImage = image ? `url('${image}')` : '';
      if (!image) [...card.classList].forEach((className) => { if (className.startsWith('gradient-')) modalImage.classList.add(className); });
      galleryModal.classList.add('active');
      galleryModal.setAttribute('aria-hidden', 'false');
    });
  });
  function closeGalleryModal() { galleryModal.classList.remove('active'); galleryModal.setAttribute('aria-hidden', 'true'); }
  closeButton?.addEventListener('click', closeGalleryModal);
  galleryModal.addEventListener('click', (event) => { if (event.target === galleryModal) closeGalleryModal(); });
}

// Event registration modal
const registerModal = document.querySelector('.register-modal');
if (registerModal) {
  const closeButton = registerModal.querySelector('.modal-close');
  const selectedTitle = registerModal.querySelector('.selected-event-title');
  const form = registerModal.querySelector('#eventRegisterForm');
  document.querySelectorAll('.open-register-modal').forEach((button) => {
    button.addEventListener('click', () => {
      selectedTitle.textContent = button.dataset.eventTitle || '';
      form.action = `/events/register/${button.dataset.eventId}`;
      registerModal.classList.add('active');
      registerModal.setAttribute('aria-hidden', 'false');
    });
  });
  function closeRegisterModal() { registerModal.classList.remove('active'); registerModal.setAttribute('aria-hidden', 'true'); }
  closeButton?.addEventListener('click', closeRegisterModal);
  registerModal.addEventListener('click', (event) => { if (event.target === registerModal) closeRegisterModal(); });
}

// Lightweight dashboard canvas charts
function drawMiniChart(canvas) {
  const data = JSON.parse(canvas.dataset.chart || '[]');
  const ctx = canvas.getContext('2d');
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = rect.width * dpr;
  canvas.height = (Number(canvas.getAttribute('height')) || 200) * dpr;
  ctx.scale(dpr, dpr);
  const width = rect.width;
  const height = Number(canvas.getAttribute('height')) || 200;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#f5f8ff';
  ctx.fillRect(0, 0, width, height);
  if (!data.length) { ctx.fillStyle = '#64748b'; ctx.fillText('No data yet', 18, 30); return; }
  const max = Math.max(...data.map((item) => Number(item.total || 0)), 1);
  const barWidth = Math.max(18, (width - 36) / data.length - 10);
  data.forEach((item, i) => {
    const barHeight = ((height - 55) * Number(item.total || 0)) / max;
    const x = 18 + i * (barWidth + 10);
    const y = height - 30 - barHeight;
    const gradient = ctx.createLinearGradient(0, y, 0, height);
    gradient.addColorStop(0, '#1769ff');
    gradient.addColorStop(1, '#22d3ee');
    ctx.fillStyle = gradient;
    ctx.fillRect(x, y, barWidth, barHeight);
    ctx.fillStyle = '#0f172a';
    ctx.font = '12px Arial';
    ctx.fillText(String(item.total), x, y - 6);
    ctx.fillStyle = '#64748b';
    ctx.fillText(String(item.label || '').slice(0, 10), x, height - 10);
  });
}
document.querySelectorAll('.mini-chart').forEach(drawMiniChart);
window.addEventListener('resize', () => document.querySelectorAll('.mini-chart').forEach(drawMiniChart));

// Chatbot
const chatbot = document.querySelector('[data-chatbot]');
if (chatbot) {
  const toggle = chatbot.querySelector('.chatbot-toggle');
  const close = chatbot.querySelector('.chatbot-close');
  const messages = chatbot.querySelector('.chatbot-messages');
  const form = chatbot.querySelector('.chatbot-form');
  const input = form?.querySelector('input[name="message"]');
  const leadForm = chatbot.querySelector('.chatbot-lead-form');
  const statusText = chatbot.querySelector('.chatbot-status');
  function timeNow() { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
  function addMessage(text, type='bot-message') {
    const bubble = document.createElement('div');
    bubble.className = `${type} message-bubble`;
    bubble.innerHTML = `<span></span><time>${timeNow()}</time>`;
    bubble.querySelector('span').textContent = text;
    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
  }
  async function sendMessage(text) {
    addMessage(text, 'user-message');
    const typing = document.createElement('div');
    typing.className = 'bot-message message-bubble typing';
    typing.textContent = 'Assistant is typing...';
    messages.appendChild(typing);
    messages.scrollTop = messages.scrollHeight;
    try {
      const response = await fetch('/api/chatbot/message', { method:'POST', headers:{ 'Content-Type':'application/json', 'X-CSRFToken': csrfToken }, body:JSON.stringify({ message:text, page_url:window.location.href }) });
      const data = await response.json();
      typing.remove();
      addMessage(data.reply || 'Sorry, I could not understand that. Please contact support.');
    } catch (error) {
      typing.remove();
      addMessage('I am having trouble connecting right now. Please use the Contact Us form.');
    }
  }
  toggle?.addEventListener('click', () => chatbot.classList.toggle('open'));
  close?.addEventListener('click', () => chatbot.classList.remove('open'));
  form?.addEventListener('submit', (event) => { event.preventDefault(); const text = input.value.trim(); if (!text) return; input.value=''; sendMessage(text); });
  chatbot.querySelectorAll('.quick-replies button').forEach((button) => button.addEventListener('click', () => sendMessage(button.textContent.trim())));
  leadForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(leadForm).entries());
    statusText.textContent = 'Sending your inquiry...';
    try {
      const response = await fetch('/api/chatbot/inquiry', { method:'POST', headers:{ 'Content-Type':'application/json', 'X-CSRFToken': csrfToken }, body:JSON.stringify(payload) });
      const data = await response.json();
      statusText.textContent = data.message || 'Inquiry saved.';
      if (response.ok) { leadForm.reset(); addMessage('Your chatbot inquiry has been saved. Our team will contact you soon.'); }
    } catch (error) { statusText.textContent = 'Unable to send. Please use Contact Us page.'; }
  });
}
